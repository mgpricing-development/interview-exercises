const registrationDomainCheck = async (event, context) => {
  console.log("registrationDomainCheck", JSON.stringify(event));
  return event;
};

module.exports = {
  registrationDomainCheck,
};
